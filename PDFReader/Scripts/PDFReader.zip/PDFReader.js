﻿$("form").submit(function (e) {
    e.preventDefault();
    var formData = new FormData(this);

    $.ajax({
        url: 'https://localhost:44328/home/FileUploaderAjax',
        type: 'POST',
        data: formData,
        success: function (data) {
            
            console.log(data)
            $('[name="Total"]').val(data.Total);
            $('[name="Color"]').val(data.Colored);
            $('[name="BlackAndWhite"]').val(data.BlackAndWhite);
        },
        cache: false,
        contentType: false,
        processData: false
    });
});

function SubmitAJAX() {
    $("form").submit();

   //var  data = new FormData();
   // data.append('file', $('#PDFFileName')[0].files[0]);

   // $.ajax({
   //     url: 'https://localhost:44328/home/FileUploaderAjax',
   //     type: 'POST',
   //     data: data,
   //     success: function (data) {

   //         console.log(data)
   //         $('[name="Total"]').val(data.Total);
   //         $('[name="Color"]').val(data.Colored);
   //         $('[name="BlackAndWhite"]').val(data.BlackAndWhite);
   //     },
   //     cache: false,
   //     contentType: false,
   //     processData: false
   // });

}